#include <WiFi.h>
#include <PubSubClient.h>
#include <ESP32Servo.h>

const int LED_PIN = 2;
const int SERVO_PIN = 15;

// Python teachable_mqtt.py의 값과 정확히 같아야 합니다.
const char* MQTT_SERVER = "test.mosquitto.org";
const int MQTT_PORT = 1883;
const char* MQTT_TOPIC =
  "jbnu/smart-iot/2026-seonghyeon/action";

WiFiClient wifiClient;
PubSubClient mqttClient(wifiClient);
Servo servo;

void setWaitState() {
  digitalWrite(LED_PIN, LOW);
  servo.write(90);
}

void applyAction(String action) {
  action.trim();
  action.toUpperCase();

  Serial.print("받은 action: ");
  Serial.println(action);

  if (action == "ROCK") {
    digitalWrite(LED_PIN, LOW);
    servo.write(0);
    Serial.println("바위: LED=OFF / SERVO=0");
  }
  else if (action == "SCISSORS") {
    digitalWrite(LED_PIN, HIGH);
    servo.write(90);
    Serial.println("가위: LED=ON / SERVO=90");
  }
  else if (action == "PAPER") {
    servo.write(180);

    for (int i = 0; i < 3; i++) {
      digitalWrite(LED_PIN, HIGH);
      delay(150);
      digitalWrite(LED_PIN, LOW);
      delay(150);
    }

    Serial.println("보: LED=3회 깜빡임 / SERVO=180");
  }
  else if (action == "WAIT") {
    setWaitState();
    Serial.println("대기: LED=OFF / SERVO=90");
  }
  else {
    setWaitState();
    Serial.println("알 수 없는 action -> 안전 대기 상태");
  }
}

void mqttCallback(
  char* topic,
  byte* payload,
  unsigned int length
) {
  String message = "";

  for (unsigned int i = 0; i < length; i++) {
    message += static_cast<char>(payload[i]);
  }

  applyAction(message);
}

void connectWiFi() {
  Serial.print("Wokwi WiFi 연결 중");
  WiFi.begin("Wokwi-GUEST", "", 6);

  while (WiFi.status() != WL_CONNECTED) {
    delay(250);
    Serial.print(".");
  }

  Serial.println();
  Serial.println("WiFi 연결 완료");
}

void connectMQTT() {
  while (!mqttClient.connected()) {
    Serial.print("MQTT 연결 중...");

    String clientId = "wokwi-rps-";
    clientId += String(random(0xffff), HEX);

    if (mqttClient.connect(clientId.c_str())) {
      Serial.println("연결 완료");

      if (mqttClient.subscribe(MQTT_TOPIC)) {
        Serial.print("구독 토픽: ");
        Serial.println(MQTT_TOPIC);
      }
      else {
        Serial.println("토픽 구독 실패");
      }
    }
    else {
      Serial.print("실패, 상태 코드=");
      Serial.println(mqttClient.state());
      delay(2000);
    }
  }
}

void setup() {
  Serial.begin(115200);

  pinMode(LED_PIN, OUTPUT);

  servo.setPeriodHertz(50);
  servo.attach(SERVO_PIN, 500, 2400);
  setWaitState();

  connectWiFi();

  mqttClient.setServer(MQTT_SERVER, MQTT_PORT);
  mqttClient.setCallback(mqttCallback);
}

void loop() {
  if (!mqttClient.connected()) {
    connectMQTT();
  }

  mqttClient.loop();
  delay(10);
}
