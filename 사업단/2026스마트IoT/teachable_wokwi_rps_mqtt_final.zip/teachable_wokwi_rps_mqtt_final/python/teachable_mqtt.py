from __future__ import annotations

import os
import threading
import time
import uuid
from pathlib import Path

import cv2
import numpy as np
import paho.mqtt.client as mqtt
from tensorflow.keras.models import load_model


BASE_DIR = Path(__file__).resolve().parent
MODEL_PATH = BASE_DIR / "converted_keras" / "keras_model.h5"
LABELS_PATH = BASE_DIR / "converted_keras" / "labels.txt"

# Wokwi sketch.ino의 값과 정확히 같아야 합니다.
MQTT_BROKER = "test.mosquitto.org"
MQTT_PORT = 1883
MQTT_TOPIC = "jbnu/smart-iot/2026-seonghyeon/action"

CAMERA_INDEX = 0
CONFIDENCE_THRESHOLD = 0.85
STABLE_FRAMES = 5

# Teachable Machine 라벨을 ESP32가 처리할 영문 명령으로 변환합니다.
ACTION_MAP = {
    "바위": "ROCK",
    "가위": "SCISSORS",
    "보": "PAPER",
}

DISPLAY_MAP = {
    "바위": "ROCK",
    "가위": "SCISSORS",
    "보": "PAPER",
}


def load_labels(path: Path) -> list[str]:
    labels: list[str] = []

    with path.open("r", encoding="utf-8") as file:
        for line in file:
            text = line.strip()
            if not text:
                continue

            # 예: "0 바위" -> "바위"
            parts = text.split(maxsplit=1)
            labels.append(parts[1] if len(parts) == 2 else parts[0])

    if not labels:
        raise RuntimeError("labels.txt에서 라벨을 읽지 못했습니다.")

    return labels


def preprocess_frame(frame: np.ndarray) -> np.ndarray:
    """웹캠 프레임을 TM 입력 형식인 224x224 RGB, -1~1 범위로 변환합니다."""
    rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    height, width = rgb.shape[:2]

    side = min(height, width)
    x1 = (width - side) // 2
    y1 = (height - side) // 2
    square = rgb[y1:y1 + side, x1:x1 + side]

    resized = cv2.resize(square, (224, 224), interpolation=cv2.INTER_AREA)
    normalized = resized.astype(np.float32) / 127.5 - 1.0

    return np.expand_dims(normalized, axis=0)


def create_mqtt_client() -> mqtt.Client:
    connected_event = threading.Event()

    def on_connect(
        client: mqtt.Client,
        userdata: object,
        flags: mqtt.ConnectFlags,
        reason_code: mqtt.ReasonCode,
        properties: mqtt.Properties | None,
    ) -> None:
        print(f"MQTT 연결 결과: {reason_code}")
        if reason_code == 0:
            connected_event.set()

    def on_disconnect(
        client: mqtt.Client,
        userdata: object,
        disconnect_flags: mqtt.DisconnectFlags,
        reason_code: mqtt.ReasonCode,
        properties: mqtt.Properties | None,
    ) -> None:
        print(f"MQTT 연결 종료: {reason_code}")

    client = mqtt.Client(
        mqtt.CallbackAPIVersion.VERSION2,
        client_id=f"tm-python-{uuid.uuid4().hex[:10]}",
    )
    client.on_connect = on_connect
    client.on_disconnect = on_disconnect

    print(f"MQTT 연결 시도: {MQTT_BROKER}:{MQTT_PORT}")
    client.connect(MQTT_BROKER, MQTT_PORT, keepalive=60)
    client.loop_start()

    if not connected_event.wait(timeout=10):
        client.loop_stop()
        client.disconnect()
        raise RuntimeError("MQTT 브로커 연결을 10초 안에 완료하지 못했습니다.")

    print(f"MQTT 토픽: {MQTT_TOPIC}")
    return client


def publish_action(client: mqtt.Client, action: str) -> None:
    result = client.publish(
        MQTT_TOPIC,
        payload=action,
        qos=0,
        retain=True,
    )
    result.wait_for_publish(timeout=5)

    if result.rc != mqtt.MQTT_ERR_SUCCESS or not result.is_published():
        raise RuntimeError(
            f"MQTT 발행 실패: action={action}, result={result.rc}"
        )

    print(f"MQTT 전송 완료: {action}")


def open_camera() -> cv2.VideoCapture:
    if os.name == "nt":
        cap = cv2.VideoCapture(CAMERA_INDEX, cv2.CAP_DSHOW)
    else:
        cap = cv2.VideoCapture(CAMERA_INDEX)

    if not cap.isOpened():
        raise RuntimeError(
            "웹캠을 열 수 없습니다. 다른 프로그램이 카메라를 사용 중인지 "
            "또는 CAMERA_INDEX 값을 확인하세요."
        )

    return cap


def main() -> None:
    print("Teachable Machine 모델을 불러오는 중...")
    model = load_model(MODEL_PATH, compile=False)
    labels = load_labels(LABELS_PATH)

    print(f"라벨: {labels}")
    print(
        f"판정 조건: confidence >= {CONFIDENCE_THRESHOLD:.2f}, "
        f"연속 {STABLE_FRAMES}프레임"
    )

    mqtt_client = create_mqtt_client()
    cap = open_camera()

    candidate_action: str | None = None
    candidate_count = 0
    last_sent_action: str | None = None

    try:
        publish_action(mqtt_client, "WAIT")
        last_sent_action = "WAIT"

        while True:
            ok, frame = cap.read()
            if not ok:
                print("웹캠 프레임을 읽지 못했습니다.")
                break

            input_data = preprocess_frame(frame)
            probabilities = model.predict(input_data, verbose=0)[0]

            class_index = int(np.argmax(probabilities))
            confidence = float(probabilities[class_index])
            label = labels[class_index]
            predicted_action = ACTION_MAP.get(label, "WAIT")

            if confidence >= CONFIDENCE_THRESHOLD and predicted_action != "WAIT":
                if predicted_action == candidate_action:
                    candidate_count += 1
                else:
                    candidate_action = predicted_action
                    candidate_count = 1

                if (
                    candidate_count >= STABLE_FRAMES
                    and predicted_action != last_sent_action
                ):
                    publish_action(mqtt_client, predicted_action)
                    last_sent_action = predicted_action
            else:
                candidate_action = None
                candidate_count = 0

                if last_sent_action != "WAIT":
                    publish_action(mqtt_client, "WAIT")
                    last_sent_action = "WAIT"

            height, width = frame.shape[:2]
            side = min(height, width)
            x1 = (width - side) // 2
            y1 = (height - side) // 2
            cv2.rectangle(
                frame,
                (x1, y1),
                (x1 + side, y1 + side),
                (255, 255, 255),
                2,
            )

            display_label = DISPLAY_MAP.get(label, label)
            stable_progress = min(candidate_count, STABLE_FRAMES)
            status = (
                f"CLASS: {display_label}  "
                f"CONF: {confidence:.2f}  "
                f"STABLE: {stable_progress}/{STABLE_FRAMES}  "
                f"SENT: {last_sent_action or 'WAIT'}"
            )
            cv2.putText(
                frame,
                status,
                (20, 40),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.62,
                (0, 255, 0),
                2,
                cv2.LINE_AA,
            )

            cv2.imshow("Teachable Machine -> MQTT -> Wokwi", frame)

            if cv2.waitKey(1) & 0xFF == ord("q"):
                break

    finally:
        try:
            if mqtt_client.is_connected():
                publish_action(mqtt_client, "WAIT")
                time.sleep(0.2)
        except Exception as exc:
            print(f"종료 WAIT 전송 생략: {exc}")

        cap.release()
        cv2.destroyAllWindows()
        mqtt_client.loop_stop()
        mqtt_client.disconnect()


if __name__ == "__main__":
    main()
