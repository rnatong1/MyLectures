# Teachable Machine → MQTT → Wokwi 가위바위보

## 구성

```text
웹캠 → Teachable Machine 모델 → ROCK/SCISSORS/PAPER
     → MQTT 브로커 → Wokwi ESP32 → LED/서보
```

- 모델: `python/converted_keras/keras_model.h5`
- 라벨: 바위, 가위, 보
- MQTT 토픽: `jbnu/smart-iot/2026-seonghyeon/action`
- LED: GPIO 2
- 서보 신호: GPIO 15

> 모델에 `기타/손 없음` 클래스가 없으므로 손이 없는 화면도 세 클래스 중 하나로 분류될 수 있습니다. 코드에서는 신뢰도 0.85 이상, 같은 결과 5프레임 연속 조건으로 오작동을 줄입니다.

## 1. Wokwi 설정

기존 ESP32+LED+서보 회로를 그대로 사용합니다.

1. `wokwi/sketch.ino` 전체를 Wokwi 코드에 붙여넣습니다.
2. Library Manager에서 `PubSubClient`, `ESP32Servo`를 추가합니다.
3. 시뮬레이션을 시작합니다.
4. Serial Monitor에서 다음을 확인합니다.

```text
WiFi 연결 완료
MQTT 연결 중...연결 완료
구독 토픽: jbnu/smart-iot/2026-seonghyeon/action
```

## 2. Python 패키지 설치

Python 3.10 가상환경이 활성화된 상태에서 프로젝트 최상위 폴더로 이동합니다.

```powershell
cd D:\workspace\teachable_wokwi_rps_mqtt_final
python -m pip install -r .\python\requirements.txt
```

가상환경을 활성화하지 않고 직접 실행할 때는 해당 가상환경의 `python.exe` 경로를 사용해도 됩니다.

## 3. MQTT 통신만 테스트

Wokwi 시뮬레이션을 먼저 켜고 실행합니다.

```powershell
python .\python\mqtt_test.py ROCK
python .\python\mqtt_test.py SCISSORS
python .\python\mqtt_test.py PAPER
python .\python\mqtt_test.py WAIT
```

## 4. 전체 모델 실행

```powershell
python .\python\teachable_mqtt.py
```

웹캠 창에서 `q`를 누르면 종료합니다.

## 동작 매핑

| 모델 결과 | MQTT 명령 | Wokwi 반응 |
|---|---|---|
| 바위 | ROCK | LED OFF, 서보 0도 |
| 가위 | SCISSORS | LED ON, 서보 90도 |
| 보 | PAPER | LED 3회 깜빡임, 서보 180도 |
| 낮은 신뢰도 | WAIT | LED OFF, 서보 90도 |

## 설정 변경 위치

Python의 다음 값과 Wokwi의 값이 반드시 동일해야 합니다.

```text
MQTT_SERVER/BROKER = test.mosquitto.org
MQTT_PORT = 1883
MQTT_TOPIC = jbnu/smart-iot/2026-seonghyeon/action
```

판정 민감도를 바꾸려면 `python/teachable_mqtt.py`에서 수정합니다.

```python
CONFIDENCE_THRESHOLD = 0.85
STABLE_FRAMES = 5
```
