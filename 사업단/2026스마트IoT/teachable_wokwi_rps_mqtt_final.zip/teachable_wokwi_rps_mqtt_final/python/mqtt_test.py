from __future__ import annotations

import argparse
import time
import uuid

import paho.mqtt.client as mqtt


MQTT_BROKER = "test.mosquitto.org"
MQTT_PORT = 1883
MQTT_TOPIC = "jbnu/smart-iot/2026-seonghyeon/action"
VALID_ACTIONS = ("ROCK", "SCISSORS", "PAPER", "WAIT")


def main() -> None:
    parser = argparse.ArgumentParser(
        description="AI 모델 없이 Wokwi MQTT 반응만 시험합니다."
    )
    parser.add_argument(
        "action",
        choices=VALID_ACTIONS,
        type=str.upper,
        help="전송할 명령",
    )
    args = parser.parse_args()

    client = mqtt.Client(
        mqtt.CallbackAPIVersion.VERSION2,
        client_id=f"mqtt-test-{uuid.uuid4().hex[:10]}",
    )
    client.connect(MQTT_BROKER, MQTT_PORT, keepalive=60)
    client.loop_start()

    try:
        time.sleep(0.5)
        result = client.publish(
            MQTT_TOPIC,
            payload=args.action,
            qos=0,
            retain=True,
        )
        result.wait_for_publish(timeout=5)
        print(f"전송 완료: {args.action}")
        print(f"토픽: {MQTT_TOPIC}")
    finally:
        client.loop_stop()
        client.disconnect()


if __name__ == "__main__":
    main()
